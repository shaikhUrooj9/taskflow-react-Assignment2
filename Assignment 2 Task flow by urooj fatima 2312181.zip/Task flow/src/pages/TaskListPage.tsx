

import TaskCard from "../components/TaskCard";

import { Task } from "../types/task";

type Props = {
  tasks: Task[];

  onDelete: (id: number) => void;

  onEdit: (task: Task) => void;
};

export default function TaskListPage({
  tasks,
  onDelete,
  onEdit,
}: Props) {
  return (
    <div className="page">
      <h2>My Tasks</h2>

      <div className="task-grid">
        {tasks.map((task) => (
          <TaskCard
            key={task.id}
            task={task}
            onDelete={onDelete}
            onEdit={onEdit}
          />
        ))}
      </div>
    </div>
  );
}