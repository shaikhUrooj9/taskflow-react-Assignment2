import TaskForm from "../components/TaskForm";

import { Task } from "../types/task";

type Props = {
  onSaveTask: (task: Task) => void;

  editingTask: Task | null;
};

export default function CreateTaskPage({
  onSaveTask,
  editingTask,
}: Props) {
  return (
    <div className="page">
      <TaskForm
        onSaveTask={onSaveTask}
        editingTask={editingTask}
      />
    </div>
  );
}