import {
  BrowserRouter,
  Routes,
  Route,
  useNavigate,
} from "react-router-dom";

import { useState } from "react";

import Header from "./components/Header";

import Navbar from "./components/Navbar";

import TaskListPage from "./pages/TaskListPage";

import CreateTaskPage from "./pages/CreateTaskPage";

import { initialTasks } from "./data/mockTasks";

import { Task } from "./types/task";

function AppContent() {
  const [tasks, setTasks] =
    useState<Task[]>(initialTasks);

  const [editingTask, setEditingTask] =
    useState<Task | null>(null);

  const navigate = useNavigate();

  const handleDeleteTask = (
    id: number
  ) => {
    setTasks(
      tasks.filter(
        (task) => task.id !== id
      )
    );
  };

  const handleSaveTask = (
    task: Task
  ) => {
    if (editingTask) {
      setTasks(
        tasks.map((t) =>
          t.id === task.id ? task : t
        )
      );

      setEditingTask(null);
    } else {
      setTasks([...tasks, task]);
    }

    navigate("/");
  };

  const handleEditTask = (
    task: Task
  ) => {
    setEditingTask(task);

    navigate("/create");
  };

  return (
    <>
      <Header />

      <Navbar />

      <div className="container">
        <Routes>
          <Route
            path="/"
            element={
              <TaskListPage
                tasks={tasks}
                onDelete={
                  handleDeleteTask
                }
                onEdit={
                  handleEditTask
                }
              />
            }
          />

          <Route
            path="/create"
            element={
              <CreateTaskPage
                onSaveTask={
                  handleSaveTask
                }
                editingTask={
                  editingTask
                }
              />
            }
          />
        </Routes>
      </div>
    </>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AppContent />
    </BrowserRouter>
  );
}