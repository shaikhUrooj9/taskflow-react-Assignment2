import {
  useEffect,
  useState,
} from "react";

import {
  Task,
  TaskPriority,
  TaskStatus,
} from "../types/task";

type Props = {
  onSaveTask: (task: Task) => void;

  editingTask: Task | null;
};

export default function TaskForm({
  onSaveTask,
  editingTask,
}: Props) {
  const [title, setTitle] =
    useState<string>("");

  const [description, setDescription] =
    useState<string>("");

  const [status, setStatus] =
    useState<TaskStatus>("Todo");

  const [priority, setPriority] =
    useState<TaskPriority>("Low");

  const [dueDate, setDueDate] =
    useState<string>("");

  const [error, setError] =
    useState<string>("");

  useEffect(() => {
    if (editingTask) {
      setTitle(editingTask.title);

      setDescription(
        editingTask.description
      );

      setStatus(editingTask.status);

      setPriority(
        editingTask.priority
      );

      setDueDate(
        editingTask.dueDate || ""
      );
    }
  }, [editingTask]);

  const clearForm = () => {
    setTitle("");

    setDescription("");

    setStatus("Todo");

    setPriority("Low");

    setDueDate("");

    setError("");
  };

  const handleSubmit = (
    event: React.FormEvent<HTMLFormElement>
  ) => {
    event.preventDefault();

    if (title.trim() === "") {
      setError(
        "Task title is required"
      );

      return;
    }

    setError("");

    const task: Task = {
      id: editingTask
        ? editingTask.id
        : Date.now(),

      title,

      description,

      status,

      priority,

      dueDate,

      createdAt: editingTask
        ? editingTask.createdAt
        : new Date()
            .toISOString()
            .split("T")[0],
    };

    onSaveTask(task);

    clearForm();
  };

  return (
    <div className="card">
      <h2>
        {editingTask
          ? "Update Task"
          : "Create Task"}
      </h2>

      <form onSubmit={handleSubmit}>
        <label>Title</label>

        <input
          type="text"
          value={title}
          onChange={(e) =>
            setTitle(e.target.value)
          }
          placeholder="Enter title"
        />

        <label>Description</label>

        <input
          type="text"
          value={description}
          onChange={(e) =>
            setDescription(
              e.target.value
            )
          }
          placeholder="Description"
        />

        <label>Status</label>

        <select
          value={status}
          onChange={(e) =>
            setStatus(
              e.target
                .value as TaskStatus
            )
          }
        >
          <option value="Todo">
            Todo
          </option>

          <option value="In Progress">
            In Progress
          </option>

          <option value="Done">
            Done
          </option>
        </select>

        <label>Priority</label>

        <select
          value={priority}
          onChange={(e) =>
            setPriority(
              e.target
                .value as TaskPriority
            )
          }
        >
          <option value="Low">
            Low
          </option>

          <option value="Medium">
            Medium
          </option>

          <option value="High">
            High
          </option>
        </select>

        <label>Due Date</label>

        <input
          type="date"
          value={dueDate}
          onChange={(e) =>
            setDueDate(e.target.value)
          }
        />

        <p className="error">
          {error}
        </p>

        <div className="buttons">
          <button
            type="button"
            className="btn clear"
            onClick={clearForm}
          >
            Clear
          </button>

          <button
            type="submit"
            className="btn create"
          >
            {editingTask
              ? "Update Task"
              : "Create Task"}
          </button>
        </div>
      </form>
    </div>
  );
}