export default function Header() {
  return (
    <header className="header">
      <div className="logo">TF</div>

      <div className="title">
        <h2>TaskFlow </h2>
        <p>Project Management</p>
      </div>

      <button className="btn logout">
        Logout
      </button>
    </header>
  );
}