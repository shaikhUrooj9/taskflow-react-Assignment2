import { Task } from "../types/task";

type TaskCardProps = {
  task: Task;

  onDelete: (id: number) => void;

  onEdit: (task: Task) => void;
};

export default function TaskCard({
  task,
  onDelete,
  onEdit,
}: TaskCardProps) {
  return (
    <div className="task-card">
      <h3>{task.title}</h3>

      <p>{task.description}</p>

      <p>
        <strong>Status:</strong>{" "}
        {task.status}
      </p>

      <p>
        <strong>Priority:</strong>{" "}
        {task.priority}
      </p>

      <p>
        <strong>Created:</strong>{" "}
        {task.createdAt}
      </p>

      {task.dueDate && (
        <p>
          <strong>Due:</strong>{" "}
          {task.dueDate}
        </p>
      )}

      <div className="task-buttons">
        <button
          className="btn edit"
          onClick={() => onEdit(task)}
        >
          Edit
        </button>

        <button
          className="btn delete"
          onClick={() =>
            onDelete(task.id)
          }
        >
          Delete
        </button>
      </div>
    </div>
  );
}