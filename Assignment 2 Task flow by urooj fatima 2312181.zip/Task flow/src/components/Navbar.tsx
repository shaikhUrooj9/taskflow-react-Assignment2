import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <nav className="navbar">
      <Link to="/">Tasks</Link>

      <Link to="/create">
        New Task
      </Link>
    </nav>
  );
}