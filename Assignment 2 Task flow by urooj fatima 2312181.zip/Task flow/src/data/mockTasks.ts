import { Task } from "../types/task";

export const initialTasks: Task[] = [
  {
    id: 1,
    title: "Complete HTML structure",
    description:
      "Create semantic HTML structure for TaskFlow.",
    status: "Todo",
    priority: "High",
    dueDate: "2026-05-22",
    createdAt: "2026-05-20",
  },

  {
    id: 2,
    title: "Design Navbar",
    description:
      "Add responsive navigation bar.",
    status: "In Progress",
    priority: "Medium",
    dueDate: "2026-05-23",
    createdAt: "2026-05-20",
  },

  {
    id: 3,
    title: "Build Task Card",
    description:
      "Create reusable task card component.",
    status: "Todo",
    priority: "High",
    dueDate: "2026-05-25",
    createdAt: "2026-05-20",
  },

  {
    id: 4,
    title: "Add Form Validation",
    description:
      "Validate title field.",
    status: "Done",
    priority: "Low",
    dueDate: "2026-05-24",
    createdAt: "2026-05-20",
  },

  {
    id: 5,
    title: "Setup React Router",
    description:
      "Create routing between pages.",
    status: "Todo",
    priority: "Medium",
    dueDate: "2026-05-26",
    createdAt: "2026-05-20",
  },
];